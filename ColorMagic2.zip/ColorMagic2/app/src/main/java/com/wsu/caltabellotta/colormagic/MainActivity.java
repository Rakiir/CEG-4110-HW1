package com.wsu.caltabellotta.colormagic;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.Math;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        Button changer_button = findViewById(R.id.color_button);
        changer_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int r, g, b;
                r = (int) (Math.random() * 255);
                g = (int) (Math.random() * 255);
                b = (int) (Math.random() * 255);
                TextView user_text = findViewById(R.id.editText);
                user_text.setTextColor(Color.rgb(r, g, b));

                TextView bg = findViewById(R.id.backgroundColor);
                bg.setBackgroundColor(Color.rgb(r, g, b));

                String hexColor = String.format("#%06X", (0xFFFFFF & Color.rgb(r, g, b)));
                TextView stats_text = findViewById(R.id.textView);
                String stats = "r=" + r + "; g=" + g + "; b=" + b + "; " + hexColor;
                stats_text.setText(stats);
            }
        });


    }
}
